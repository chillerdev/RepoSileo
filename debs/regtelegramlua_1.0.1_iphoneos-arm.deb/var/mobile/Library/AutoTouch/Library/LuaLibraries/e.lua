-- e.lua
-- Thư viện giải mã dùng cho bundle RegTelegramLua.at tải về từ server:
--   * serial()  : license/device key — PHẢI TRÙNG với license đã kích hoạt trên server
--   * load(tok) : base64_decode + xor_crypt → trả về chunk Lua (dùng trong bundle template)
--
-- Bundle template (server trả về):
--   local e = require("e")
--   local <module> = e.load("<encrypted>")
--   return <module>

local B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local B64MAP = {}
for i = 1, #B64 do B64MAP[B64:sub(i, i)] = i - 1 end

-- AutoTouch Lua 5.4 có sẵn bit operator (~, &, |, <<, >>)
if not bit32 then
    bit32 = {}
    function bit32.bxor(a, b) return a ~ b end
    function bit32.band(a, b) return a & b end
    function bit32.bor(a, b)  return a | b end
    function bit32.lshift(a, b) return a << b end
    function bit32.rshift(a, b) return a >> b end
end

local _M = {}

-- License key của THIẾT BỊ này.
-- Server phải kích hoạt key này trước (POST /api/licenses {"license_key": "..."}).
function _M.serial()
    return "F74QP8SGGRY8"
end

local function base64_decode(s)
    s = s:gsub('%s+', ''):gsub('[^A-Za-z0-9%+/%=]', '')
    local out = {}
    local i = 1
    while i <= #s do
        local c1 = s:sub(i, i); i = i + 1
        local c2 = s:sub(i, i); i = i + 1
        local c3 = s:sub(i, i); i = i + 1
        local c4 = s:sub(i, i); i = i + 1
        if not c1 or not c2 then break end

        local n1 = B64MAP[c1]
        local n2 = B64MAP[c2]
        if n1 == nil or n2 == nil then return "" end
        local n3 = (c3 ~= '=' and B64MAP[c3]) or 0
        local n4 = (c4 ~= '=' and B64MAP[c4]) or 0

        local triple = n1 * 262144 + n2 * 4096 + n3 * 64 + n4
        local a = math.floor(triple / 65536) % 256
        local b = math.floor(triple / 256) % 256
        local c = triple % 256

        out[#out + 1] = string.char(a)
        if c3 ~= '=' then out[#out + 1] = string.char(b) end
        if c4 ~= '=' then out[#out + 1] = string.char(c) end
    end
    return table.concat(out)
end

local function xor_crypt(str)
    local key = _M.serial()
    local res = {}
    for i = 1, #str do
        local c = string.byte(str, i)
        local k = string.byte(key, ((i - 1) % #key) + 1)
        res[i] = string.char(bit32.bxor(c, k))
    end
    return table.concat(res)
end

function _M.load(token)
    return load(xor_crypt(base64_decode(token)))
end

return _M
