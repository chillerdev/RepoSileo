-- b.lua
-- Bundle downloader cho RegTelegramLua.at (AutoTouch iOS).
--
-- Chuỗi công việc:
--   1) GET {SERVER}/api/encrypt?key=<license>  → JSON {images, names, modules}
--        modules = { "<tên file .lua>": "code template chứa e.load(...)" }
--   2) Ghi từng module vào <bundle path>/<tên file>
--   3) Gom names → <bundle path>/name.txt
--   4) Tải từng ảnh từ {SERVER}/api/image/<file> → <bundle path>/images/
--   5) Verify các file bắt buộc có dung lượng > 0
--
-- Bundle path truyền vào từ setup.lua: rootDir() .. "/RegTelegramLua.at/"

local lfs  = require("lfs")
local curl = require("cURL")
local json = require("json")
local e    = require("e")

-- ═════════════ CẤU HÌNH ═════════════
local SERVER = "https://ttdevduck.top"     -- server chính thức (HTTPS, Let's Encrypt)
local RETRY_NET   = 3                     -- số lần thử request asset/JSON
local RETRY_IMAGE = 3
local REQUIRED_MODULES = {                -- file bắt buộc phải có sau khi tải
    "main.lua", "app.lua", "base_class.lua", "config.lua",
    "telegram.lua", "functions.lua", "helper.lua", "email.lua",
    "phone.lua", "proxy.lua", "blacklist.lua", "changer.lua",
}
-- ════════════════════════════════════

local function request_get(url)
    local result = ""
    local ok, err = pcall(function()
        local c = curl.easy{
            url = url,
            ssl_verifypeer = false,
            ssl_verifyhost = false,
            followlocation = true,
            timeout = 30,
            connecttimeout = 15,
            httpheader = {
                "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) " ..
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
                "Accept: application/json, text/html;q=0.9,*/*;q=0.8",
                "Connection: keep-alive"
            },
            writefunction = function(chunk)
                result = result .. chunk
                return true
            end
        }
        c:perform()
        c:close()
    end)
    if not ok or result == "" then
        return nil, err
    end
    return result
end

local function request_json(url, retry)
    retry = retry or RETRY_NET
    for i = 1, retry do
        local result, err = request_get(url)
        if result then
            local ok, decoded = pcall(json.decode, result)
            if ok and type(decoded) == "table" then
                return decoded
            end
            toast("JSON lỗi: " .. tostring(result):sub(1, 80), 3)
        else
            toast("GET lỗi lần " .. i .. "/" .. retry .. ": " .. tostring(err), 1)
        end
        usleep(2000000)
    end
    return nil
end

local function write_file(path, text)
    local file = io.open(path, "w")
    if not file then
        toast("Ghi file lỗi: " .. path, 3)
        return false
    end
    file:write(text)
    file:close()
    return true
end

local function file_size(path)
    local attr = lfs.attributes(path)
    return attr and attr.size or 0
end

local function download_image(url, path, retry)
    retry = retry or RETRY_IMAGE

    local folder = path:match("(.*/)")
    if folder then
        os.execute('mkdir -p "' .. folder .. '"')
    end

    for attempt = 1, retry do
        local f = io.open(path, "wb")
        if not f then
            toast("Không mở được file ảnh: " .. path, 3)
            return false
        end

        local ok, err = pcall(function()
            local c = curl.easy{
                url = url,
                ssl_verifypeer = false,
                ssl_verifyhost = false,
                followlocation = true,
                timeout = 60,
                connecttimeout = 20,
                writefunction = function(chunk)
                    f:write(chunk)
                    return true
                end
            }
            c:perform()
            c:close()
        end)
        f:close()

        if ok and file_size(path) > 0 then
            toast("Tải ảnh OK: " .. tostring(path:match("[^/]+$")), 1)
            return true
        end

        toast("Tải ảnh lỗi lần " .. attempt .. "/" .. retry .. ": " .. tostring(err or "empty"), 1)
        usleep(2000000)
    end
    return false
end

-- ═════════════ BUILD CHÍNH ═════════════
local _M = {}

function _M.b(path)
    -- tạo thư mục bundle
    lfs.mkdir(path)
    lfs.mkdir(path .. "/images/")

    toast("Bắt đầu tải bundle từ " .. SERVER, 3)

    -- 1) tải manifest (modules + names + images)
    local manifest = request_json(SERVER .. "/api/encrypt?key=" .. e.serial())
    if not manifest then
        toast("KHÔNG lấy được bundle. Kiểm tra license/serial và server!", 5)
        return false
    end

    if not manifest.modules or next(manifest.modules) == nil then
        toast("Bundle rỗng — license chưa kích hoạt sai serial!", 5)
        return false
    end

    -- 2) ghi các module .lua
    local count = 0
    for k, v in pairs(manifest.modules) do
        if v and #v > 0 then
            if write_file(path .. k, v) then
                count = count + 1
            end
        end
    end
    toast("Đã ghi " .. count .. " module lua", 2)

    -- 3) name.txt (danh sách tên random)
    local tmp = ""
    for _, name in pairs(manifest.names or {}) do
        tmp = tmp .. name .. "\n"
    end
    if not write_file(path .. "name.txt", tmp) then
        toast("KHÔNG ghi được name.txt!", 4)
        return false
    end

    -- 4) tải ảnh
    local img_fail = 0
    local url_base = SERVER .. "/api/image/"
    for _, filename in pairs(manifest.images or {}) do
        if not download_image(url_base .. filename, path .. "/images/" .. filename) then
            img_fail = img_fail + 1
        end
    end
    toast("Ảnh tải xong, lỗi: " .. img_fail, 2)

    -- 5) verify các module bắt buộc
    local missing = {}
    for _, name in ipairs(REQUIRED_MODULES) do
        if file_size(path .. name) == 0 then
            missing[#missing + 1] = name
        end
    end

    if #missing > 0 then
        toast("THIẾU file: " .. table.concat(missing, ", "), 5)
        return false
    end

    toast("SETUP HOÀN TẤT! Chạy RegTelegramLua.at/main.lua để bắt đầu.", 5)
    return true
end

return _M
