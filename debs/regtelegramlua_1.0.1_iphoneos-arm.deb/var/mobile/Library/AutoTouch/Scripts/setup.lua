-- setup.lua
-- Script chạy trong AutoTouch để cài đặt bundle RegTelegramLua.at
-- (tải toàn bộ code mã hóa + ảnh về thiết bị, ghi vào rootDir()/RegTelegramLua.at/)

local build = require("b")
build.b(rootDir() .. "/RegTelegramLua.at/")
